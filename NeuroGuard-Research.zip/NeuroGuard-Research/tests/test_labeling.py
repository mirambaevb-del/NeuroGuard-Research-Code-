import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))
from neuroguard.data.labeling import label_windows

def test_preictal_and_interictal_labels():
    # 1 Hz, 4-second windows, seizure onset at 20,000s, end at 20,010s.
    starts = [0, 18200, 19000, 19996, 20000, 24000]
    labels = label_windows(starts, 4, 1, [(20000, 20010)], 30, 4)
    assert labels.tolist() == [0, 1, 1, 1, -1, 0]
