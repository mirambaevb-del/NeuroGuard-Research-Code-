# NeuroGuard Research — EEGNet baseline

Research implementation for binary EEG-window classification on CHB-MIT:
- `0 = interictal`
- `1 = preictal` (the 30 minutes before an annotated seizure)

**This is a research baseline, not a medical device or a clinically validated seizure-warning system.**
It does not establish that a seizure can be predicted in real time.

## Pipeline

1. Read CHB-MIT EDF files and the matching `chbXX-summary.txt`.
2. Apply 0.5–40 Hz band-pass and 60 Hz notch filters.
3. Split signals into 4-second windows with 50% overlap.
4. Label windows:
   - preictal: within 30 minutes before seizure onset;
   - interictal: outside the preictal period and outside the 4-hour pre-seizure exclusion buffer;
   - ictal and ambiguous windows are excluded.
5. Split by patient (never randomly split windows across train/validation/test).
6. Train a compact EEGNet baseline and report threshold-dependent metrics.

## Important scientific limitations

- CHB-MIT is a scalp EEG dataset; performance on it does not imply performance on a wearable device.
- The provided patient split is a starting example. Confirm every subject has usable recordings and seizure annotations before interpreting results.
- Patient-level holdout reduces leakage but results from a small number of subjects have high uncertainty.
- Accuracy is not sufficient because interictal windows greatly outnumber preictal windows.
- Report sensitivity, specificity, precision, F1, balanced accuracy, confusion matrix, and the operating threshold. For a genuine warning-system study, also evaluate false alarms per hour and warning time using continuous recordings.
- This first version uses window-level classification and does not yet implement alarm aggregation or a prospective prediction protocol.

## Dataset setup

Download CHB-MIT from PhysioNet and place the extracted files under:

```text
data/raw/chbmit/
  chb01/
    chb01_01.edf
    chb01-summary.txt
  chb02/
    ...
```

Do not upload CHB-MIT EDF files to GitHub. The dataset has its own access and use terms.

## Installation

Python 3.10–3.12 is recommended.

```bash
python -m venv .venv
# Windows PowerShell:
.venv\Scripts\Activate.ps1
# Linux/macOS:
source .venv/bin/activate

pip install -r requirements.txt
```

## 1. Prepare windows

Edit `configs/chbmit.yaml` to match the subjects available locally. Then:

```bash
python scripts/prepare_data.py --config configs/chbmit.yaml
```

The script writes compressed per-recording `.npz` files under `data/processed/`.

## 2. Train

```bash
python scripts/train.py --config configs/chbmit.yaml
```

The best validation-loss checkpoint is saved under `artifacts/`.

## 3. Evaluate

```bash
python scripts/evaluate.py --config configs/chbmit.yaml
```

Evaluation is patient-held-out according to the configured `test_subjects`.

## Attribution

EEGNet is an established compact CNN architecture for EEG decoding. This repository contains an implementation inspired by the published EEGNet architecture:

Lawhern, V. J. et al. (2018). *EEGNet: a compact convolutional neural network for EEG-based brain–computer interfaces*. Journal of Neural Engineering, 15(5), 056013. https://doi.org/10.1088/1741-2552/aace8c

This repository is an independent research implementation; it is not the official EEGNet repository.
