import random
import numpy as np
import torch
from torch import nn
from torch.utils.data import DataLoader
from sklearn.metrics import (accuracy_score, balanced_accuracy_score,
    precision_recall_fscore_support, confusion_matrix, roc_auc_score)

def set_seed(seed):
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)

def make_loader(dataset, batch_size, shuffle, num_workers=0):
    return DataLoader(dataset, batch_size=batch_size, shuffle=shuffle,
                      num_workers=num_workers, pin_memory=torch.cuda.is_available())

def run_epoch(model, loader, criterion, device, optimizer=None):
    training = optimizer is not None
    model.train(training)
    total_loss, total = 0.0, 0
    all_y, all_prob = [], []
    for X, y in loader:
        X, y = X.to(device), y.to(device)
        if training:
            optimizer.zero_grad(set_to_none=True)
        with torch.set_grad_enabled(training):
            logits = model(X)
            loss = criterion(logits, y)
            if training:
                loss.backward()
                optimizer.step()
        probs = torch.softmax(logits.detach(), dim=1)[:, 1]
        total_loss += loss.item() * len(y)
        total += len(y)
        all_y.extend(y.cpu().numpy().tolist())
        all_prob.extend(probs.cpu().numpy().tolist())
    return total_loss / max(total, 1), np.asarray(all_y), np.asarray(all_prob)

def metric_report(y_true, prob, threshold=0.5):
    pred = (prob >= threshold).astype(int)
    precision, recall, f1, _ = precision_recall_fscore_support(
        y_true, pred, labels=[1], average=None, zero_division=0)
    cm = confusion_matrix(y_true, pred, labels=[0, 1])
    specificity = cm[0, 0] / max(cm[0].sum(), 1)
    try:
        auc = roc_auc_score(y_true, prob)
    except ValueError:
        auc = float("nan")
    return {
        "threshold": float(threshold),
        "accuracy": float(accuracy_score(y_true, pred)),
        "balanced_accuracy": float(balanced_accuracy_score(y_true, pred)),
        "preictal_precision": float(precision[0]),
        "preictal_sensitivity": float(recall[0]),
        "preictal_f1": float(f1[0]),
        "interictal_specificity": float(specificity),
        "roc_auc": float(auc),
        "confusion_matrix_rows_true_cols_pred": cm.tolist(),
        "n_windows": int(len(y_true)),
        "n_interictal": int((y_true == 0).sum()),
        "n_preictal": int((y_true == 1).sum())
    }
