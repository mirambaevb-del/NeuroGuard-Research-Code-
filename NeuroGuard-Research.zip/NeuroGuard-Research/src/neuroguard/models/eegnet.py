import torch
from torch import nn

class EEGNet(nn.Module):
    """Compact EEGNet-style network for input [batch, 1, channels, samples]."""
    def __init__(self, n_channels, n_samples, dropout=0.5, F1=8, D=2, F2=16,
                 kernel_length=64):
        super().__init__()
        if kernel_length > n_samples:
            kernel_length = max(8, n_samples // 2)
        self.features = nn.Sequential(
            nn.Conv2d(1, F1, (1, kernel_length), padding=(0, kernel_length // 2), bias=False),
            nn.BatchNorm2d(F1),
            nn.Conv2d(F1, F1 * D, (n_channels, 1), groups=F1, bias=False),
            nn.BatchNorm2d(F1 * D),
            nn.ELU(),
            nn.AvgPool2d((1, 4)),
            nn.Dropout(dropout),
            nn.Conv2d(F1 * D, F1 * D, (1, 16), padding=(0, 8), groups=F1 * D, bias=False),
            nn.Conv2d(F1 * D, F2, (1, 1), bias=False),
            nn.BatchNorm2d(F2),
            nn.ELU(),
            nn.AvgPool2d((1, 8)),
            nn.Dropout(dropout),
        )
        with torch.no_grad():
            dummy = torch.zeros(1, 1, n_channels, n_samples)
            flat_dim = self.features(dummy).flatten(1).shape[1]
        self.classifier = nn.Linear(flat_dim, 2)

    def forward(self, x):
        return self.classifier(self.features(x).flatten(1))
