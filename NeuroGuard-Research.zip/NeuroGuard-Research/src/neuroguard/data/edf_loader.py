from pathlib import Path
import numpy as np
import mne
from .annotations import parse_summary
from .preprocessing import filter_signal, make_windows
from .labeling import label_windows

def find_subject_files(raw_dir, subject):
    subject_dir = Path(raw_dir) / subject
    summaries = list(subject_dir.glob("*-summary.txt"))
    if not summaries:
        raise FileNotFoundError(f"No summary file found in {subject_dir}")
    annotations = parse_summary(summaries[0])
    edfs = sorted(subject_dir.glob("*.edf"))
    return [(p, annotations.get(p.name, [])) for p in edfs]

def prepare_recording(edf_path, seizures, cfg):
    raw = mne.io.read_raw_edf(edf_path, preload=True, verbose="ERROR")
    requested = cfg["dataset"]["channels"]
    available_upper = {name.upper(): name for name in raw.ch_names}
    picks = [available_upper[name.upper()] for name in requested if name.upper() in available_upper]
    if len(picks) < int(cfg["dataset"].get("min_channels", 8)):
        raise ValueError(f"{edf_path.name}: only {len(picks)} configured channels found")
    raw.pick(picks)
    target_sfreq = float(cfg["signal"]["target_sfreq"])
    if abs(raw.info["sfreq"] - target_sfreq) > 1e-6:
        raw.resample(target_sfreq, npad="auto", verbose="ERROR")
    sfreq = float(raw.info["sfreq"])
    data = raw.get_data(units="uV")
    data = filter_signal(data, sfreq, cfg["signal"]["l_freq"],
                         cfg["signal"]["h_freq"], cfg["signal"]["notch_freq"])
    windows, starts = make_windows(data, sfreq, cfg["signal"]["window_seconds"],
                                   cfg["signal"]["overlap"])
    if not seizures:
        # A recording without annotated seizures can contribute interictal
        # windows, but only if its summary explicitly includes that EDF.
        labels = np.zeros(len(starts), dtype=np.int64)
    else:
        labels = label_windows(
            starts, windows.shape[-1], sfreq, seizures,
            cfg["signal"]["preictal_minutes"],
            cfg["signal"]["interictal_exclusion_hours"]
        )
    keep = labels >= 0
    return windows[keep], labels[keep], picks

def prepare_subject(raw_dir, subject, processed_dir, cfg):
    out_dir = Path(processed_dir) / subject
    out_dir.mkdir(parents=True, exist_ok=True)
    counts = {0: 0, 1: 0}
    written = 0
    for edf_path, seizures in find_subject_files(raw_dir, subject):
        try:
            x, y, channels = prepare_recording(edf_path, seizures, cfg)
        except Exception as exc:
            print(f"[SKIP] {edf_path.name}: {exc}")
            continue
        if len(y) == 0:
            print(f"[SKIP] {edf_path.name}: no labelled windows")
            continue
        safe_name = edf_path.stem.replace(".", "_")
        out_path = out_dir / f"{safe_name}.npz"
        np.savez_compressed(out_path, X=x, y=y, channels=np.asarray(channels))
        counts[0] += int((y == 0).sum())
        counts[1] += int((y == 1).sum())
        written += 1
        print(f"[OK] {subject}/{edf_path.name}: {len(y)} windows "
              f"(interictal={(y==0).sum()}, preictal={(y==1).sum()})")
    return written, counts
