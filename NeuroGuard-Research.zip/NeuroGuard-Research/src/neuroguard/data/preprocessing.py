import numpy as np
from scipy.signal import butter, sosfiltfilt, iirnotch, filtfilt

def filter_signal(data, sfreq, l_freq=0.5, h_freq=40.0, notch_freq=60.0):
    """Filter array shaped [channels, samples], returning float32."""
    x = np.asarray(data, dtype=np.float64)
    nyquist = sfreq / 2.0
    high = min(h_freq, nyquist * 0.95)
    low = max(l_freq, 0.01)
    if low >= high:
        raise ValueError(f"Invalid bandpass for sampling rate {sfreq}: {low}-{high} Hz")
    sos = butter(4, [low, high], btype="bandpass", fs=sfreq, output="sos")
    x = sosfiltfilt(sos, x, axis=-1)
    if notch_freq < nyquist:
        b, a = iirnotch(notch_freq, Q=30, fs=sfreq)
        x = filtfilt(b, a, x, axis=-1)
    return x.astype(np.float32)

def make_windows(data, sfreq, window_seconds=4.0, overlap=0.5):
    n_samples = int(round(window_seconds * sfreq))
    step = max(1, int(round(n_samples * (1.0 - overlap))))
    if data.shape[-1] < n_samples:
        return np.empty((0, data.shape[0], n_samples), dtype=np.float32), np.array([], dtype=np.int64)
    starts = np.arange(0, data.shape[-1] - n_samples + 1, step, dtype=np.int64)
    windows = np.stack([data[:, s:s+n_samples] for s in starts]).astype(np.float32)
    return windows, starts
