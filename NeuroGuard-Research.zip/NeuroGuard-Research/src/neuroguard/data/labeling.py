import numpy as np

def label_windows(starts, window_samples, sfreq, seizures,
                  preictal_minutes=30, interictal_exclusion_hours=4):
    """Label complete windows; discard windows intersecting ictal/ambiguous zones.

    seizure intervals are in seconds relative to the EDF start.
    Preictal is [onset - preictal_duration, onset). Interictal is only
    outside [onset - exclusion_buffer, seizure_end]. This conservative rule
    prevents the interictal class from containing the immediate pre-seizure
    exclusion interval.
    """
    duration = window_samples / sfreq
    pre = preictal_minutes * 60.0
    exclusion = interictal_exclusion_hours * 3600.0
    labels = np.full(len(starts), -1, dtype=np.int64)
    for i, sample_start in enumerate(starts):
        t0 = sample_start / sfreq
        t1 = t0 + duration
        overlaps_ictal = False
        is_preictal = False
        in_exclusion = False
        for onset, end in seizures:
            onset, end = float(onset), float(end)
            if t0 < end and t1 > onset:
                overlaps_ictal = True
                break
            if t0 >= onset - pre and t1 <= onset:
                is_preictal = True
            if t0 < end and t1 > onset - exclusion:
                in_exclusion = True
        if overlaps_ictal:
            continue
        if is_preictal:
            labels[i] = 1
        elif not in_exclusion:
            labels[i] = 0
    return labels
