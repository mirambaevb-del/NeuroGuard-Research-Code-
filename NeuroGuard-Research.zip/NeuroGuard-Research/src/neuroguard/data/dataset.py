from pathlib import Path
import numpy as np
import torch
from torch.utils.data import Dataset

class WindowDataset(Dataset):
    def __init__(self, files):
        self.items = []
        for path in files:
            with np.load(path, allow_pickle=False) as z:
                X = z["X"].astype(np.float32)
                y = z["y"].astype(np.int64)
            if len(y):
                self.items.append((X, y, str(path)))
        self.index = []
        for item_idx, (X, y, _) in enumerate(self.items):
            self.index.extend((item_idx, i) for i in range(len(y)))
        if not self.index:
            raise ValueError("No labelled windows found. Run prepare_data.py first.")
    def __len__(self):
        return len(self.index)
    def __getitem__(self, idx):
        item_idx, row = self.index[idx]
        X, y, _ = self.items[item_idx]
        # EEGNet expects [1, channels, samples]
        x = torch.from_numpy(X[row][None, :, :])
        return x, torch.tensor(y[row], dtype=torch.long)

def files_for_subjects(processed_dir, subjects):
    paths = []
    for subject in subjects:
        paths.extend(sorted((Path(processed_dir) / subject).glob("*.npz")))
    return paths
