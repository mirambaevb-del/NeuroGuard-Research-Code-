from pathlib import Path
import re

def parse_summary(summary_path):
    """Return {edf_filename: [(seizure_start_seconds, seizure_end_seconds), ...]}.

    CHB-MIT summary times are offsets within each EDF recording.
    """
    text = Path(summary_path).read_text(encoding="utf-8", errors="ignore")
    current_file = None
    events = {}
    for raw_line in text.splitlines():
        line = raw_line.strip()
        m = re.match(r"File Name:\s*(\S+)", line, re.I)
        if m:
            current_file = m.group(1)
            events.setdefault(current_file, [])
            continue
        if current_file is None:
            continue
        start = re.match(r"Seizure\s+\d+\s+Start Time:\s*(\d+)\s*seconds", line, re.I)
        end = re.match(r"Seizure\s+\d+\s+End Time:\s*(\d+)\s*seconds", line, re.I)
        if start:
            events[current_file].append([int(start.group(1)), None])
        elif end:
            if events[current_file] and events[current_file][-1][1] is None:
                events[current_file][-1][1] = int(end.group(1))
    return {k: [(s, e) for s, e in v if e is not None and e >= s] for k, v in events.items()}
