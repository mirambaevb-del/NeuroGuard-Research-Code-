from pathlib import Path
import yaml

def load_config(path):
    with open(path, "r", encoding="utf-8") as f:
        cfg = yaml.safe_load(f)
    return cfg

def ensure_dirs(cfg):
    Path(cfg["dataset"]["processed_dir"]).mkdir(parents=True, exist_ok=True)
    Path(cfg["output"]["artifacts_dir"]).mkdir(parents=True, exist_ok=True)
    Path(cfg["output"]["results_dir"]).mkdir(parents=True, exist_ok=True)
