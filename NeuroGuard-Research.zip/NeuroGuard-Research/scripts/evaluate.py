import argparse, sys, json
from pathlib import Path
import numpy as np
import torch
from torch import nn
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))
from neuroguard.config import load_config, ensure_dirs
from neuroguard.data.dataset import WindowDataset, files_for_subjects
from neuroguard.models.eegnet import EEGNet
from neuroguard.training.engine import make_loader, run_epoch, metric_report

def main():
    p = argparse.ArgumentParser()
    p.add_argument("--config", default="configs/chbmit.yaml")
    p.add_argument("--threshold", type=float, default=0.5)
    args = p.parse_args()
    cfg = load_config(args.config); ensure_dirs(cfg)
    ckpt_path = Path(cfg["output"]["artifacts_dir"]) / "eegnet_best.pt"
    if not ckpt_path.exists():
        raise FileNotFoundError("Checkpoint not found. Run scripts/train.py first.")
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    ckpt = torch.load(ckpt_path, map_location=device, weights_only=False)
    model = EEGNet(ckpt["n_channels"], ckpt["n_samples"], **cfg["model"]).to(device)
    model.load_state_dict(ckpt["model_state_dict"])
    test_files = files_for_subjects(cfg["dataset"]["processed_dir"], cfg["dataset"]["subjects"]["test"])
    ds = WindowDataset(test_files)
    loader = make_loader(ds, cfg["training"]["batch_size"], False, cfg["training"]["num_workers"])
    criterion = nn.CrossEntropyLoss()
    _, y, prob = run_epoch(model, loader, criterion, device)
    report = metric_report(y, prob, args.threshold)
    report["test_subjects"] = cfg["dataset"]["subjects"]["test"]
    report["checkpoint"] = str(ckpt_path)
    out = Path(cfg["output"]["results_dir"]); out.mkdir(parents=True, exist_ok=True)
    out_file = out / "test_metrics.json"
    out_file.write_text(json.dumps(report, indent=2), encoding="utf-8")
    print(json.dumps(report, indent=2))
    print(f"Saved: {out_file}")
if __name__ == "__main__":
    main()
