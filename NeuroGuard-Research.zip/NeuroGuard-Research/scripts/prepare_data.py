import argparse, sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))
from neuroguard.config import load_config, ensure_dirs
from neuroguard.data.edf_loader import prepare_subject

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", default="configs/chbmit.yaml")
    args = parser.parse_args()
    cfg = load_config(args.config)
    ensure_dirs(cfg)
    raw_dir, processed_dir = cfg["dataset"]["raw_dir"], cfg["dataset"]["processed_dir"]
    subjects = list(dict.fromkeys(
        cfg["dataset"]["subjects"]["train"] +
        cfg["dataset"]["subjects"]["validation"] +
        cfg["dataset"]["subjects"]["test"]))
    for subject in subjects:
        count, labels = prepare_subject(raw_dir, subject, processed_dir, cfg)
        print(f"{subject}: files={count}, interictal={labels[0]}, preictal={labels[1]}")
if __name__ == "__main__":
    main()
