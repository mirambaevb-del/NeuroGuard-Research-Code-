import argparse, sys, json
from pathlib import Path
import numpy as np
import torch
from torch import nn
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))
from neuroguard.config import load_config, ensure_dirs
from neuroguard.data.dataset import WindowDataset, files_for_subjects
from neuroguard.models.eegnet import EEGNet
from neuroguard.training.engine import set_seed, make_loader, run_epoch, metric_report

def main():
    p = argparse.ArgumentParser()
    p.add_argument("--config", default="configs/chbmit.yaml")
    args = p.parse_args()
    cfg = load_config(args.config); ensure_dirs(cfg)
    t = cfg["training"]; set_seed(t["seed"])
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    train_files = files_for_subjects(cfg["dataset"]["processed_dir"], cfg["dataset"]["subjects"]["train"])
    val_files = files_for_subjects(cfg["dataset"]["processed_dir"], cfg["dataset"]["subjects"]["validation"])
    train_ds, val_ds = WindowDataset(train_files), WindowDataset(val_files)
    sample_x, _ = train_ds[0]
    model_cfg = cfg["model"]
    model = EEGNet(sample_x.shape[1], sample_x.shape[2], **model_cfg).to(device)
    y_train = np.concatenate([np.load(f, allow_pickle=False)["y"] for f in train_files])
    counts = np.bincount(y_train, minlength=2)
    if (counts == 0).any():
        raise ValueError(f"Training split must contain both classes; counts={counts.tolist()}")
    weights = torch.tensor(len(y_train) / (2.0 * counts), dtype=torch.float32, device=device)
    criterion = nn.CrossEntropyLoss(weight=weights if t.get("use_class_weights", True) else None)
    optimizer = torch.optim.Adam(model.parameters(), lr=t["learning_rate"], weight_decay=t["weight_decay"])
    train_loader = make_loader(train_ds, t["batch_size"], True, t["num_workers"])
    val_loader = make_loader(val_ds, t["batch_size"], False, t["num_workers"])
    best, bad = float("inf"), 0
    artifact_dir = Path(cfg["output"]["artifacts_dir"]); artifact_dir.mkdir(parents=True, exist_ok=True)
    for epoch in range(1, t["epochs"] + 1):
        tr_loss, _, _ = run_epoch(model, train_loader, criterion, device, optimizer)
        va_loss, yv, pv = run_epoch(model, val_loader, criterion, device)
        print(f"Epoch {epoch:02d}: train_loss={tr_loss:.4f} val_loss={va_loss:.4f} "
              f"val_bal_acc={metric_report(yv,pv)['balanced_accuracy']:.4f}")
        if va_loss < best:
            best, bad = va_loss, 0
            torch.save({"model_state_dict": model.state_dict(),
                        "n_channels": int(sample_x.shape[1]),
                        "n_samples": int(sample_x.shape[2]),
                        "config": cfg, "best_val_loss": best}, artifact_dir / "eegnet_best.pt")
        else:
            bad += 1
            if bad >= t["patience"]:
                print("Early stopping.")
                break
    print(f"Best validation loss: {best:.4f}; device: {device}")
if __name__ == "__main__":
    main()
